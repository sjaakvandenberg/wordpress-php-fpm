scnShortcodeMeta={
	attributes:[
		{
			label:"Big Content",
			id:"content",
			help: 'Content that should be displayed big (eg: Number).',
			isRequired:true
		},
		{
			label:"Small Content to the left ",
			id:"left",
			help: 'Small Content to the left (eg % symbol)'
		},
		{
			label:"Small Content below",
			id:"bellow",
			help: 'The small content below.'
		}
		],
		defaultContent:"2147",
		shortcode:"big_box"
};
